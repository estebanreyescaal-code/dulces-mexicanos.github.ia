
"use client";
import { useEffect, useState } from "react";

export default function AdminPage() {
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("admin_token");
    if (token === "admin1234") {
      setAuthorized(true);
    } else {
      window.location.href = "/admin/login";
    }
  }, []);

  if (!authorized) return null;

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Zona Administrativa</h1>
      <p className="text-lg">Aquí puedes editar tu sitio web de forma segura.</p>
      {/* Puedes agregar herramientas aquí */}
    </div>
  );
}
